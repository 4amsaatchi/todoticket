# Jet Compare Wishlist

## Changelog

### 1.0.2
* Added: need helps links to widgets
* Added: changelog
* Added: Jet Popups compatibility
* Fixed: Minor bugs

### 1.0.1
* FIX : bug with add default option

### 1.0.0