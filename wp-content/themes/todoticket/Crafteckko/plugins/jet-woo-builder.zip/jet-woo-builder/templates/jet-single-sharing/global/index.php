<?php
/**
 * Sharing template
 */

woocommerce_template_single_sharing();
