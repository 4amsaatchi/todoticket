<?php
/**
 * Active filters title template
 */
?>
<div class="jet-active-filters__title"><?php
	if ( $title ) {
		echo $title;
	}
?></div>